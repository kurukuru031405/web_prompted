-- Run once if the LMS has not already added the archive flag automatically.
ALTER TABLE `student` ADD COLUMN `isArchive` TINYINT(1) NOT NULL DEFAULT 0;
