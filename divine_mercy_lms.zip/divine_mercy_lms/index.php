<?php
require __DIR__.'/config.php';
if (logged_in()) { header('Location: '.(current_user()['role']==='teacher'?'teacher.php':'admin.php')); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $role = $_POST['role'] ?? 'teacher'; $id = trim($_POST['username'] ?? ''); $pw = $_POST['password'] ?? '';
    try {
        if ($role === 'admin') {
            $q=db()->prepare('SELECT Name, Password FROM admin WHERE Name=?'); $q->execute([$id]); $u=$q->fetch();
            if ($u && verify_and_upgrade($pw,$u['Password'],function($hash)use($id){db()->prepare('UPDATE admin SET Password=? WHERE Name=?')->execute([$hash,$id]);})) {
                session_regenerate_id(true); $_SESSION['user']=['role'=>'admin','id'=>$u['Name'],'name'=>$u['Name']]; header('Location: admin.php'); exit;
            }
        } else {
            $q=db()->prepare('SELECT * FROM teacher WHERE ID=?'); $q->execute([$id]); $u=$q->fetch();
            if ($u && verify_and_upgrade($pw,$u['Password'],function($hash)use($id){db()->prepare('UPDATE teacher SET Password=? WHERE ID=?')->execute([$hash,$id]);})) {
                session_regenerate_id(true); $_SESSION['user']=['role'=>'teacher','id'=>$u['ID'],'name'=>full_name($u)]; header('Location: teacher.php'); exit;
            }
        }
    } catch (Throwable $ex) { $error='Unable to connect to the database. Check config.php and import the SQL file.'; }
    if (!$error) $error='Invalid login credentials. Please check your ID and password.';
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Divine Mercy College Foundation Inc. | LMS</title><link rel="stylesheet" href="assets/style.css"></head>
<body class="landing">
<header class="site-header"><a class="brand" href="index.php"><img src="assets/logo.png" alt="Divine Mercy College Foundation seal"><span>DIVINE MERCY COLLEGE<br><small>FOUNDATION INC.</small></span></a><nav><a href="#about">About</a><a href="#portals">Learning portal</a><a class="btn btn-white" href="#portals">Login</a></nav></header>
<main>
<section class="hero"><div class="hero-copy"><div class="eyebrow">LEARN • GROW • EXCEL</div><h1>Knowledge with <em>purpose.</em></h1><p>A simple learning management portal for teachers and administrators of Divine Mercy College Foundation Inc.</p><div class="hero-actions"><a class="btn btn-white" href="#portals">Access your portal <span>↗</span></a><a class="text-link" href="#about">Discover the platform ↓</a></div><div class="hero-note"><span class="dot"></span> Student progress, mastery and learning content in one place</div></div><div class="hero-emblem"><div class="seal-wrap"><img src="assets/logo.png" alt="Divine Mercy College Foundation Inc. official seal"></div><div class="seal-caption">DIVINUM ET SAPIENTIA <span>✦</span> EST. 1990</div></div></section>
<section id="portals" class="portal-section"><div class="section-heading"><div><div class="eyebrow red">SECURE ACCESS</div><h2>Choose your portal</h2></div><p>Sign in with your account credentials to continue.</p></div>
<?php if ($error): ?><div class="notice error"><?=e($error)?></div><?php endif; ?>
<div class="portal-grid"><article class="portal-card"><div class="portal-icon">♙</div><div class="card-kicker">FOR EDUCATORS</div><h3>Teacher login</h3><p>Monitor student progress, review section rankings, manage learning content and update your profile.</p><button class="btn btn-red" onclick="openLogin('teacher')">Login as teacher <span>→</span></button></article><article class="portal-card"><div class="portal-icon">▦</div><div class="card-kicker">SYSTEM MANAGEMENT</div><h3>Admin login</h3><p>Access the administrative portal to review content and manage the learning platform.</p><button class="btn btn-outline" onclick="openLogin('admin')">Login as admin <span>→</span></button></article></div>
</section>
<section id="about" class="about-section"><div><div class="eyebrow red">OUR LEARNING SPACE</div><h2>Built around student growth.</h2></div><p>Bring class performance, learning activities and student assessment records together with a clean, focused workspace designed for educators.</p></section>
</main><footer><span>© <?=date('Y')?> Divine Mercy College Foundation Inc.</span><span>Divinum et Sapientia</span></footer>
<div class="modal" id="loginModal" aria-hidden="true"><div class="modal-backdrop" onclick="closeLogin()"></div><section class="modal-panel"><button class="modal-close" onclick="closeLogin()" aria-label="Close">×</button><div class="eyebrow red" id="modalKicker">TEACHER PORTAL</div><h2 id="modalTitle">Welcome back</h2><p id="modalDescription">Sign in with your teacher ID.</p><form method="post"><input type="hidden" name="role" id="loginRole" value="teacher"><label for="username">Account ID / username</label><input id="username" name="username" autocomplete="username" required placeholder="Enter your ID"><label for="password">Password</label><input id="password" name="password" type="password" autocomplete="current-password" required placeholder="Enter your password"><button class="btn btn-red full" type="submit">Sign in securely <span>→</span></button></form><p class="modal-foot">Need access? Contact your system administrator.</p></section></div><script src="assets/app.js"></script></body></html>
