<?php
declare(strict_types=1);
session_start();

const DB_HOST = '127.0.0.1';
const DB_NAME = 'divinedb';
const DB_USER = 'root';
const DB_PASS = ''; // Set your local MySQL password here.

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $pdo = new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4', DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}
function e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function logged_in(): bool { return !empty($_SESSION['user']); }
function require_login(?string $role = null): void {
    if (!logged_in() || ($role && ($_SESSION['user']['role'] ?? '') !== $role)) {
        header('Location: index.php'); exit;
    }
}
function current_user(): array { return $_SESSION['user'] ?? []; }
function full_name(array $row): string {
    return trim(implode(' ', array_filter([$row['First_Name'] ?? '', $row['Middle_Initials'] ?? '', $row['Last_Name'] ?? ''])));
}
function verify_legacy_password(string $submitted, string $stored): bool {
    if (password_verify($submitted, $stored)) return true;
    // Existing database exports include plaintext passwords; accept them once and upgrade to a hash.
    if (hash_equals($stored, $submitted)) return true;
    return false;
}
function verify_and_upgrade(string $submitted, string $stored, callable $update): bool {
    if (!verify_legacy_password($submitted, $stored)) return false;
    if (password_needs_rehash($stored, PASSWORD_DEFAULT) || !str_starts_with($stored, '$2y$') && !str_starts_with($stored, '$argon2')) {
        $update(password_hash($submitted, PASSWORD_DEFAULT));
    }
    return true;
}
function flash(string $message, string $type='success'): void { $_SESSION['flash'] = [$message, $type]; }
function show_flash(): void {
    if (!empty($_SESSION['flash'])) { [$m,$t] = $_SESSION['flash']; unset($_SESSION['flash']); echo '<div class="notice '.e($t).'">'.e($m).'</div>'; }
}
