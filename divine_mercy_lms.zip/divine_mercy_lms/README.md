# Divine Mercy College Foundation Inc. LMS

A red-and-white PHP/MySQL learning management portal for local development with XAMPP.

## Requirements
- PHP 8.1+ (PHP 8.2+ recommended)
- MySQL or MariaDB
- Apache (XAMPP is recommended)
- For `.xlsx` imports: enable PHP `zip` and `simplexml` extensions. CSV imports work without extra packages.

## Setup
1. Extract the `divine_mercy_lms` folder into `C:\xampp\htdocs\`.
2. Start Apache and MySQL in XAMPP.
3. In phpMyAdmin, create/import the `divinedb` database using the supplied `_divinedb_.sql` export.
4. Import `database_migration.sql` into `divinedb` **once** after the original database import. It adds account status fields, admin profile fields, unique account-ID indexes, and the student-specific assessment table.
5. Check `config.php` and set `DB_HOST`, `DB_NAME`, `DB_USER`, and `DB_PASS` for your local MySQL setup.
6. Open `http://localhost/divine_mercy_lms/`.

## Portals
- Landing page: `index.php`
- Teacher portal: `teacher.php` (teacher dashboard, content, profile, individual student pages)
- Admin portal: `admin.php?page=home`

The admin navigation includes Home, Manage students, Manage teachers, Manage contents, and Admin profile. Admins can create student/teacher accounts, bulk-import `.xlsx` or `.csv` files, reset passwords, activate/deactivate accounts, edit admin content, update their profile picture and username, change their password, and log out.

### Bulk import headings
The first row is a header row. Column names are case-insensitive; spaces and punctuation are normalized to underscores.

Students require `id`, `first_name`, `last_name`, and `section`. Optional columns: `password`, `middle_name`, `player_name`, `gender`.

Teachers require `id`, `first_name`, and `last_name`. Optional columns: `password`, `middle_name`, `subject`.

If `password` is omitted or blank, a temporary password is generated and must be securely provided to the account holder. Duplicate IDs and incomplete rows are skipped. The page has a button to download a sample CSV template for each account type.

## Security notes
- Existing database passwords may be plaintext. Successful legacy logins are upgraded to password hashes by the login flow.
- Newly created/imported account passwords and reset passwords are hashed with PHP `password_hash()`.
- Change all sample/default credentials before exposing the site outside a local development environment. Use HTTPS, add CSRF protection, and restrict admin access before production use.
- Existing `pre-post_test` rows do not identify a student. Do not assign them to individual students without a confirmed mapping. Record new per-student scores in `student_test_scores`.
